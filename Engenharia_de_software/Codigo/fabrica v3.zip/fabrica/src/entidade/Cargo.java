package entidade;

import java.util.ArrayList;
import java.util.List;

public class Cargo {
    private String nomeCargo;
    private double salario;
    private List<Funcionario> listaFuncionario;

    public Cargo(String nomeCargo, double salario) {
        this.nomeCargo = nomeCargo;
        this.salario = salario;
        this.listaFuncionario = new ArrayList<>();
    }

    public String getNomeCargo() {
        return nomeCargo;
    }

    public void setNomeCargo(String nomeCargo) {
        this.nomeCargo = nomeCargo;
    }

    public double getSalario() {
        return salario;
    }

    public void setSalario(double salario) {
        this.salario = salario;
    }

    public void adicionarFuncionario (Funcionario funcionario){
        listaFuncionario.add(funcionario);
    }
    public List<Funcionario> getListaFuncionario (){
        return listaFuncionario;
    }
}
