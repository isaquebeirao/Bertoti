package entidade;

public class Main {

    public static void main(String[] args) {

        GerenciarCargo gerenciador = new GerenciarCargo();
        gerenciador.adicionarCargo("Lider", 4000.0);
        gerenciador.adicionarCargo("Supervisor", 10000.0);

        Cargo cargoLider = gerenciador.getListaCargo().get(0);
        cargoLider.adicionarFuncionario(new Funcionario("Isaque", "Beirão", "isaque@gmail.com","18/08/00"));
        cargoLider.adicionarFuncionario(new Funcionario("Lucas", "Santos", "lucas@gmail.com","06/07/00"));

        Cargo cargoSupervisor = gerenciador.getListaCargo().get(1);
        cargoSupervisor.adicionarFuncionario(new Funcionario("Vitor", "Costa", "vitor@gmail.com","20/11/97"));

        for (Cargo cargo : gerenciador.getListaCargo()) {
            System.out.println("Cargo: " + cargo.getNomeCargo());
            System.out.println("Funcionarios: ");

            for (Funcionario funcionario : cargo.getListaFuncionario()) {
                System.out.println(" -" + funcionario.getNome());
            }
            
        }
    }
}
