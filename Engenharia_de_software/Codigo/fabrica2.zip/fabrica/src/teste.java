import java.util.List;

public class teste {

	public static void main(String[] args) {

		Setor metals = new Setor("Metals");
		Fabrica lenovo = new Fabrica();

		Funcionario isaque = new Funcionario("Isaque", "1", "Metals");
		lenovo.addFuncionario(isaque);
		metals.adicionarFuncionario(isaque);
		
		 List<Funcionario> funcionariosEncontrados = lenovo.buscarFuncionarioPorRegistro("1");
		
		for(Funcionario funcionarios: funcionariosEncontrados) {
			System.out.println(funcionarios.getRegistro() + " " + funcionarios.getNome());
		}

		List<Funcionario> setorMetalsEncontrados = metals.buscarFuncionarioPorSetor("Metals");

		for (Funcionario funcionario: setorMetalsEncontrados){
			System.out.println(funcionario.getNome() + " " + funcionario.getRegistro() + " " + funcionario.getSetor());
		}
	}
	
}


//adicionar classe setor, onde vai ser criado os setores q os funcionarios vao ser alocados.