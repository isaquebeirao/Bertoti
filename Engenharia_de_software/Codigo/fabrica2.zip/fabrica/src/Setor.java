import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

public class Setor {

	private String nome;
	private List<Funcionario> funcionarios = new ArrayList<>();

	public Setor(String nome){
		this.nome = nome;
		this.funcionarios = new ArrayList<>();
	}

	public void adicionarFuncionario(Funcionario funcionario) {
		this.funcionarios.add(funcionario);
	}

	public List<Funcionario> buscarFuncionarioPorSetor(String setor){
		List<Funcionario> achados = new LinkedList<Funcionario>();
		for(Funcionario funcionario: funcionarios) {
			if(funcionario.getSetor().equals(setor))
				achados.add(funcionario);
		}
		return achados;

	}
}
