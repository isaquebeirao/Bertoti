import java.util.List;

public class teste {

	public static void main(String[] args) {
		Fabrica lenovo = new Fabrica(); //Criando uma fabrica.

		//Criando um funcionarios com nome, registro e setor.
		Funcionario isaque = new Funcionario("Isaque", "1", "Metals");
		Funcionario samuel = new Funcionario("Samuel", "2", "Espuma");
		Funcionario klebin = new Funcionario("Klebin", "3", "Metals");

		//Adicionando o funcionario criado na lista de funcionarios.
		lenovo.addFuncionario(isaque);
		lenovo.addFuncionario(samuel);
		lenovo.addFuncionario(klebin);
		
		List<Funcionario> funcionariosEncontrados = lenovo.buscarFuncionarioPorRegistro("1");//Criando uma lista para encontrar funcionario com o registro solicitado.
		
		for(Funcionario funcionarios: funcionariosEncontrados) { //Usando o for para procurar o funcionario (dentro da lista funcionarios) que possui o registro solicitado no código acima.

			System.out.println("Nome do funcionario com registro " + funcionarios.getRegistro() + ": " + funcionarios.getNome());//imprime o funcionario encontrado, mostrando o registro e o nome.
		}
		List<Funcionario> funcionariosEncontradosMetals = lenovo.buscarFuncionarioPorSetor("Metals");//Criando uma lista para encontrar funcionario(os) com o setor solicitado.

		for (Funcionario funcionarios: funcionariosEncontradosMetals){//Usando o for para procurar o funcionario(os) (dentro da lista funcionarios) que possui o setor solicitado no código acima.

			System.out.println("Funcionarios q fazem parte do setor de Metals: " + funcionarios.getNome() + " " + funcionarios.getSetor());//imprime o funcionario encontrado, mostrando o registro e o nome.
		}
		List<Funcionario> funcionariosEncontradosEspuma = lenovo.buscarFuncionarioPorSetor("Espuma");

		for (Funcionario funcionarios: funcionariosEncontradosEspuma){

			System.out.println("Funcionarios q fazem parte do setor de Espuma: " + funcionarios.getNome() + " " + funcionarios.getSetor());
		}

	}
	
}


