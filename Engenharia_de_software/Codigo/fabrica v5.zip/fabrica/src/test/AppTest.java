package test;

import entidade.*;
import org.junit.Test;
import java.util.List;
import static org.junit.Assert.*;

public class AppTest {

    @Test
    public void verificarFuncionamento(){

        GerenciarCargo gerenciarCargo = new GerenciarCargo();

        gerenciarCargo.adicionarCargo("Lider", 4000.0);
        gerenciarCargo.adicionarCargo("Supervisor", 10000.0);

        assertEquals(gerenciarCargo.getListaCargo().size(), 2);

        Cargo cargoLider = gerenciarCargo.getListaCargo().get(0);
        cargoLider.adicionarFuncionario(new Funcionario("Isaque", "Beirão", "isaque@gmail.com","18/08/00"));
        cargoLider.adicionarFuncionario(new Funcionario("Lucas", "Santos", "lucas@gmail.com","06/07/00"));

        assertEquals(cargoLider.getListaFuncionario().size(), 2);

        Cargo cargoSupervisor = gerenciarCargo.getListaCargo().get(1);
        cargoSupervisor.adicionarFuncionario(new Funcionario("Vitor", "Costa", "vitor@gmail.com","20/11/97"));

        assertEquals(cargoSupervisor.getListaFuncionario().size(), 1);

        GerenciarSetor gerenciarSetor = new GerenciarSetor();
        gerenciarSetor.adicionarSetor("Metals");

        assertEquals(gerenciarSetor.getListaSetor().size(), 1);

        Setor setorMetals = gerenciarSetor.getListaSetor().get(0);
        setorMetals.adicionarFuncionarioNoSetor(cargoLider);

        assertEquals(setorMetals.getListaFuncionarioSetor().size(), 1);


    }

}
