package entidade;

import java.util.ArrayList;
import java.util.List;

public class GerenciarCargo {
    private List<Cargo> listaCargo;

    public GerenciarCargo(){
        listaCargo = new ArrayList<>();
    }

    public void adicionarCargo (String nomeCargo, double salario){
        Cargo cargo = new Cargo(nomeCargo, salario);
        listaCargo.add(cargo);
    }

    public List<Cargo> getListaCargo() {
        return listaCargo;
    }
}
