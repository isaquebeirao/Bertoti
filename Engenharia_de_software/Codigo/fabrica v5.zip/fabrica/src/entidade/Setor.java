package entidade;

import java.util.ArrayList;
import java.util.List;

public class Setor {

    private String nomeSetor;
    private List<Cargo> listaFuncionarioSetor;

    public Setor(String nomeSetor) {
        this.nomeSetor = nomeSetor;
        this.listaFuncionarioSetor = new ArrayList<>();
    }

    public String getNomeSetor() {
        return nomeSetor;
    }

    public void setNomeSetor(String nomeSetor) {
        this.nomeSetor = nomeSetor;
    }

    public void adicionarFuncionarioNoSetor (Cargo funcionario){
        listaFuncionarioSetor.add(funcionario);
    }
    public List<Cargo> getListaFuncionarioSetor (){
        return listaFuncionarioSetor;
    }

}
