package entidade;

import java.util.ArrayList;
import java.util.List;

public class GerenciarSetor {

    private List<Setor> listaSetor;

    public GerenciarSetor(){
        listaSetor = new ArrayList<>();
    }

    public void adicionarSetor (String nomeSetor){
        Setor setor = new Setor(nomeSetor);
        listaSetor.add(setor);
    }

    public List<Setor> getListaSetor() {
        return listaSetor;
    }
}

