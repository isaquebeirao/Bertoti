package entidade;

import java.util.List;

public class Main {

    public static void main(String[] args) {

        GerenciarCargo gerenciador = new GerenciarCargo();
        gerenciador.adicionarCargo("Lider", 4000.0);
        gerenciador.adicionarCargo("Supervisor", 10000.0);
        gerenciador.adicionarCargo("Auxiliar", 1600.0);

        Cargo cargoLider = gerenciador.getListaCargo().get(0);
        cargoLider.adicionarFuncionario(new Funcionario("Isaque", "Beirão", "isaque@gmail.com","18/08/00"));
        cargoLider.adicionarFuncionario(new Funcionario("Lucas", "Santos", "lucas@gmail.com","06/07/00"));

        Cargo cargoSupervisor = gerenciador.getListaCargo().get(1);
        cargoSupervisor.adicionarFuncionario(new Funcionario("Vitor", "Costa", "vitor@gmail.com","20/11/97"));

        Cargo cargoAuxiliar = gerenciador.getListaCargo().get(2);
        cargoAuxiliar.adicionarFuncionario(new Funcionario("Douglas", "Costa", "vitor@gmail.com","20/11/97"));
        cargoAuxiliar.adicionarFuncionario(new Funcionario("Carlos", "Costa", "vitor@gmail.com","20/11/97"));
        cargoAuxiliar.adicionarFuncionario(new Funcionario("Fabil", "Costa", "vitor@gmail.com","20/11/97"));


        for (Cargo cargo : gerenciador.getListaCargo()) {
            System.out.println("Cargo: " + cargo.getNomeCargo());
            System.out.println("Funcionarios: ");

            for (Funcionario funcionario : cargo.getListaFuncionario()) {
                System.out.println(" -" + funcionario.getNome());
            }

        }

        GerenciarSetor gerenciarSetor = new GerenciarSetor();
        gerenciarSetor.adicionarSetor("Metals");

        Setor setorMetals = gerenciarSetor.getListaSetor().get(0);
        setorMetals.adicionarFuncionarioNoSetor(cargoLider);

        for (Setor setor : gerenciarSetor.getListaSetor()) {
            System.out.println("Setor: " + setor.getNomeSetor());
            System.out.println("Funcionarios: ");

            for (Funcionario funcionario : cargoAuxiliar.getListaFuncionario()) {
                System.out.println(" -" + funcionario.getNome() + " Cargo: " + cargoAuxiliar.getNomeCargo());
            }

        }

    }
}
